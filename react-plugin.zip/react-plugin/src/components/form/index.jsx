import React, { Component } from 'react';
import './index.css';

class FormCom extends Component {
    constructor(props) {
        super(props);
        this.state = {
            mobile: '',
            password: '',
        }
    }
    componentDidMount() {

    }
    _onInputChange = (e) => {
        let type = e.target.attributes.name.value
        this.setState({ [type]: e.target.value })
    }
    _onSubmit = () => {
        if (this.props.onSubmit) {
            const { mobile, password } = this.state;
            this.props.onSubmit(mobile, password);
        }
    }
    render() {
        const { mobile, password } = this.state;
        return (
            <div className="form-box_cover">
                <div className="form-box_login">
                    <div className="form-login_name">登录</div>
                    <label className="form-label_name">
                        <input type="number" name="mobile"
                            onChange={this._onInputChange}
                            value={mobile}
                            placeholder="用户名..." />
                    </label>
                    <label className="form-label_pass">
                        <input type="password" name="password"
                            onChange={this._onInputChange}
                            value={password}
                            placeholder="密码..." />
                    </label>
                    <button className="form-login_submit" onClick={this._onSubmit}>登录</button>
                </div>
            </div>
        )
    }
}

export default FormCom;