import React, { Component } from 'react';
import styles from './index.css';
export default class Share_Com extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {
        
    }
    render() {
        return (
            <div className={styles.share_url}>
                <input type="text" name="share_url" value={share_url} ref='share_url'/>
                <button className={styles.share_copy} onClick={this._Share_copy}>Copy</button>
                <div className={styles.share_close} onClick={this._Share_url_close}></div>
            </div>
            )
    }
}