import React, { Component } from 'react';
import './index.css';
import echarts from 'echarts';





export default class TipCom extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    componentDidMount() {
        this._echarts_broken_line();
        this._echarts_line_tow();
    }
    _echarts_broken_line = () => {
        // 基于准备好的dom，初始化echarts实例
        let container = this.refs.broken_line;
        let myChart = echarts.init(container);
        let charts = {
            unit: 'Kbps',
            names: ['出口', '入口'],
            lineX:
                [
                    '2018-11-11 17:01', '2018-11-11 17:02', '2018-11-11 17:03', '2018-11-11 17:04',
                    '2018-11-11 17:05', '2018-11-11 17:06', '2018-11-11 17:07', '2018-11-11 17:08',
                    '2018-11-11 17:09', '2018-11-11 17:10', '2018-11-11 17:11', '2018-11-11 17:12',
                    '2018-11-11 17:13', '2018-11-11 17:14', '2018-11-11 17:15', '2018-11-11 17:16',
                    '2018-11-11 17:17', '2018-11-11 17:18', '2018-11-11 17:19', '2018-11-11 17:20'
                ],
            value: [
                [451, 352, 303, 534, 95, 236, 217, 328, 159, 151, 231, 192, 453, 524, 165, 236, 527, 328, 129, 530],
                [360, 545, 80, 192, 330, 580, 192, 80, 250, 453, 352, 28, 625, 345, 65, 325, 468, 108, 253, 98]
            ]

        }
        let color = ['rgba(23, 255, 243', 'rgba(255,100,97']
        let lineY = []

        for (let i = 0; i < charts.names.length; i++) {
            let x = i
            if (x > color.length - 1) {
                x = color.length - 1
            }
            let data = {
                name: charts.names[i],
                type: 'line',
                color: color[x] + ')',
                smooth: true,
                areaStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: color[x] + ', 0.3)'
                        }, {
                            offset: 0.8,
                            color: color[x] + ', 0)'
                        }], false),
                        shadowColor: 'rgba(0, 0, 0, 0.1)',
                        shadowBlur: 10
                    }
                },
                symbol: 'circle',
                symbolSize: 5,
                data: charts.value[i]
            }
            lineY.push(data)
        }

        lineY[0].markLine = {
            silent: true,
            data: [
                {
                    yAxis: 5
                },
                {
                    yAxis: 100
                },
                {
                    yAxis: 200
                },
                {
                    yAxis: 300
                },
                {
                    yAxis: 400
                }
            ]
        }
        let option = {
            backgroundColor: '#1b2735',
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: charts.names,
                textStyle: {
                    fontSize: 12,
                    color: 'rgb(0,253,255,0.6)'
                },
                right: '4%'
            },
            grid: {
                top: '14%',
                left: '4%',
                right: '4%',
                bottom: '12%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: charts.lineX,
                axisLabel: {
                    textStyle: {
                        color: 'rgb(0,253,255,0.6)'
                    },
                    formatter: function (params) {
                        return params.split(' ')[0] + '\n' + params.split(' ')[1]
                    }
                }
            },
            yAxis: {
                name: charts.unit,
                type: 'value',
                axisLabel: {
                    formatter: '{value}',
                    textStyle: {
                        color: 'rgb(0,253,255,0.6)'
                    }
                },
                splitLine: {
                    lineStyle: {
                        color: 'rgb(23,255,243,0.3)'
                    }
                },
                axisLine: {
                    lineStyle: {
                        color: 'rgb(0,253,255,0.6)'
                    }
                }
            },
            series: lineY
        }
        myChart.setOption(option);
        setInterval(function () {
            myChart.setOption({
                legend: {
                    selected: {
                        '出口': false,
                        '入口': false
                    }
                }
            })
            myChart.setOption({
                legend: {
                    selected: {
                        '出口': true,
                        '入口': true
                    }
                }
            })
        }, 10000)
    }
    _echarts_line_tow() {
        let container = this.refs.broken_line_two;
        let myChart = echarts.init(container);
        let arix_x = [1, 2, 3, 4, 5, 6], arix_y = [152, 289, 283, 296, 324, 256];
        let option = {
            backgroundColor: '#394056',
            title: {
                text: '湿度',
                textStyle: {
                    fontWeight: 'normal',
                    fontSize: 12,
                    color: '#F1F1F3'
                },
                left: '6%',
                top: '3%'
            },
            tooltip: {
                trigger: 'axis', //触发类型。[ default: 'item' ] :数据项图形触发，主要在散点图，饼图等无类目轴的图表中使用;'axis'坐标轴触发，主要在柱状图，折线图等会使用类目轴的图表中使用
                axisPointer: {
                    lineStyle: {
                        color: '#57617B'
                    }
                }
            },
            legend: {
                icon: 'rect', //设置图例的图形形状，circle为圆，rect为矩形
                itemWidth: 14, //图例标记的图形宽度[ default: 25 ] 
                itemHeight: 5, //图例标记的图形高度。[ default: 14 ] 
                itemGap: 13, //图例每项之间的间隔。横向布局时为水平间隔，纵向布局时为纵向间隔。[ default: 10 ] 
                data: ['移动', '电信', '联通'],
                right: '4%', //图例组件离容器右侧的距离
                textStyle: {
                    fontSize: 12,
                    color: '#F1F1F3'
                }
            },
            grid: {
                left: '3%', //grid 组件离容器左侧的距离。
                right: '4%', //grid 组件离容器右侧的距离。
                bottom: '3%', //grid 组件离容器下侧的距离。
                containLabel: true //grid 区域是否包含坐标轴的刻度标签[ default: false ] 
            },
            xAxis: [{
                type: 'category',
                boundaryGap: false, //坐标轴两边留白策略，类目轴和非类目轴的设置和表现不一样
                axisLine: {
                    lineStyle: {
                        color: '#F1F1F3' //坐标轴线线的颜色。
                    }
                },
                data: arix_x
            }],
            yAxis: [{
                type: 'value', //坐标轴类型。'value' 数值轴，适用于连续数据;'category' 类目轴，适用于离散的类目数据，为该类型时必须通过 data 设置类目数据;'time' 时间轴;'log' 对数轴.
                name: '（刻度）', //坐标轴名称。
                axisTick: {
                    show: false //是否显示坐标轴刻度
                },
                axisLine: {
                    lineStyle: {
                        color: '#F1F1F3' //坐标轴线线的颜色
                    }
                },
                axisLabel: {
                    margin: 10, //刻度标签与轴线之间的距离
                    textStyle: {
                        fontSize: 12 //文字的字体大小
                    }
                },
                splitLine: {
                    lineStyle: {
                        color: '#57617B' //分隔线颜色设置
                    }
                }
            }],
            series: [{
                name: '日调用数量',
                type: 'line',
                smooth: true,
                symbol: 'circle',
                symbolSize: 5,
                showSymbol: false,
                lineStyle: {
                    normal: {
                        width: 1
                    }
                },
                areaStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: 'rgba(0, 136, 212, 0.3)'
                        }, {
                            offset: 0.8,
                            color: 'rgba(0, 136, 212, 0)'
                        }], false),
                        shadowColor: 'rgba(0, 0, 0, 0.1)',
                        shadowBlur: 10
                    }
                },
                itemStyle: {
                    normal: {
                        color: 'rgb(0,136,212)',
                        borderColor: 'rgba(0,136,212,0.2)',
                        borderWidth: 12

                    }
                },
                data: arix_y
            },]
        };
        myChart.setOption(option);
    }
    _handle_close = () => {
        if (this.props.onClose) {
            this.props.onClose();
        }
    }
    render() {
        const { name } = this.props;
        return (
            <div className="tip-room_msg">
                <div className="tip-room_close" onClick={this._handle_close}></div>
                <div className="tip-room_name">{name}</div>
                <ul className="tip-room_table">
                    <li>
                        <span>租户</span>
                        <span>人数</span>
                        <span>起租期</span>
                        <span>到期</span>
                    </li>
                    <li>
                        <span>景天城</span>
                        <span>200</span>
                        <span>2017.10</span>
                        <span>2020.10</span>
                    </li>
                    <li>
                        <span>能源费(￥)</span>
                        <span>物业费(￥)</span>
                        <span>停车费(￥)</span>
                        <span>维修费(￥)</span>
                    </li>
                    <li>
                        <span>1000</span>
                        <span>1000</span>
                        <span>1000</span>
                        <span>1000</span>
                    </li>
                </ul>
                <div className="tip-broken_line" ref='broken_line'></div>
                <div className="tip-broken_line_two" ref='broken_line_two'></div>
            </div>
        )
    }
}

export class Tab_out_Com extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {

    }
    _btn_click = (e) => {
        if (this.props.onBtn) {
            this.props.onBtn(e)
        }
    }
    render() {
        const { name, data } = this.props;
        return (
            <div className="tip-project_tab_out">
                <div className="tip-project_rooms_title">{name}</div>
                <div className="tip-project_rooms_name">Rooms</div>
                <ul className="tip-project_rooms_all">
                    <li className="tip-li_room" key='0'>Name</li>
                    {
                        data.length > 0 && data.map(item =>
                            <li className="tip-li_room"
                                onClick={this._btn_click}
                                data_id={item.BIM_ID}
                                key={item.BIM_ID}>{item.DISPLAY_NAME}
                            </li>)
                    }
                </ul>
            </div>
        )
    }
}

export class Tab_inner_Com extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {

    }
    _btn_back = () => {
        if (this.props.onBack) {
            this.props.onBack()
        }
    }
    _btn_prev = () => {
        if (this.props.onPrev) {
            this.props.onPrev()
        }
    }
    _btn_next = () => {
        if (this.props.onNext) {
            this.props.onNext()
        }
    }
    render() {
        const { room_index, room_floor, room_item } = this.props;
        return (
            <div className="tip-project_tab_inner">
                <div className="tip-inner_head">
                    <div onClick={this._btn_back}>Rooms</div>
                    <div className={room_index == 0 ? "tip-inner_prev" : ''}
                        onClick={this._btn_prev}>Prev</div>
                    <div className={room_index == room_floor.length - 1 ? "tip-inner_next" : ''}
                        onClick={this._btn_next}>Next</div>
                </div>
                <div className="tip-inner_title">{room_item.DISPLAY_NAME}</div>
                <ul className="tip-inner_all">
                    <li><span>编码</span><span>{room_item.DISPLAY_CODE}</span></li>
                    <li><span>高度</span><span>{room_item.HEIGHT}</span></li>
                    <li><span>房间面积</span><span>{room_item.AREA}</span></li>
                    <li><span>周长</span><span>{room_item.PERIMETER}</span></li>
                    <li><span>净周长(除门宽)</span><span>{room_item.NET_PERIMETER}</span></li>
                    <li><span>门数量</span><span>{room_item.DOOR_COUNT}</span></li>
                    <li><span>墙面积</span><span>{room_item.WALL_AREA}</span></li>
                </ul>
            </div>
        )
    }
}

export class TipComApp extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    componentDidMount() {
        this._echarts_broken_line();
        this._echarts_line_tow();
    }
    _echarts_broken_line = () => {
        // 基于准备好的dom，初始化echarts实例
        let container = this.refs.broken_line;
        let myChart = echarts.init(container);
        let charts = {
            unit: 'Kbps',
            names: ['出口', '入口'],
            lineX: [
                '2018-11-11 17:01', '2018-11-11 17:02', '2018-11-11 17:03', '2018-11-11 17:04', '2018-11-11 17:05',
                '2018-11-11 17:06', '2018-11-11 17:07', '2018-11-11 17:08', '2018-11-11 17:09', '2018-11-11 17:10',
                '2018-11-11 17:11', '2018-11-11 17:12', '2018-11-11 17:13', '2018-11-11 17:14', '2018-11-11 17:15',
                '2018-11-11 17:16', '2018-11-11 17:17', '2018-11-11 17:18', '2018-11-11 17:19', '2018-11-11 17:20'
            ],
            value: [
                [451, 352, 303, 534, 95, 236, 217, 328, 159, 151, 231, 192, 453, 524, 165, 236, 527, 328, 129, 530],
                [360, 545, 80, 192, 330, 580, 192, 80, 250, 453, 352, 28, 625, 345, 65, 325, 468, 108, 253, 98]
            ]

        }
        let color = ['rgba(23, 255, 243', 'rgba(255,100,97']
        let lineY = []

        for (let i = 0; i < charts.names.length; i++) {
            let x = i
            if (x > color.length - 1) {
                x = color.length - 1
            }
            let data = {
                name: charts.names[i],
                type: 'line',
                color: color[x] + ')',
                smooth: true,
                areaStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: color[x] + ', 0.3)'
                        }, {
                            offset: 0.8,
                            color: color[x] + ', 0)'
                        }], false),
                        shadowColor: 'rgba(0, 0, 0, 0.1)',
                        shadowBlur: 10
                    }
                },
                symbol: 'circle',
                symbolSize: 5,
                data: charts.value[i]
            }
            lineY.push(data)
        }

        lineY[0].markLine = {
            silent: true,
            data: [{
                yAxis: 5
            }, {
                yAxis: 100
            }, {
                yAxis: 200
            }, {
                yAxis: 300
            }, {
                yAxis: 400
            }]
        }
        let option = {
            backgroundColor: '#1b2735',
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: charts.names,
                textStyle: {
                    fontSize: 12,
                    color: 'rgb(0,253,255,0.6)'
                },
                right: '4%'
            },
            grid: {
                top: '14%',
                left: '4%',
                right: '4%',
                bottom: '12%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: charts.lineX,
                axisLabel: {
                    textStyle: {
                        color: 'rgb(0,253,255,0.6)'
                    },
                    formatter: function (params) {
                        return params.split(' ')[0] + '\n' + params.split(' ')[1]
                    }
                }
            },
            yAxis: {
                name: charts.unit,
                type: 'value',
                axisLabel: {
                    formatter: '{value}',
                    textStyle: {
                        color: 'rgb(0,253,255,0.6)'
                    }
                },
                splitLine: {
                    lineStyle: {
                        color: 'rgb(23,255,243,0.3)'
                    }
                },
                axisLine: {
                    lineStyle: {
                        color: 'rgb(0,253,255,0.6)'
                    }
                }
            },
            series: lineY
        }
        myChart.setOption(option);
        setInterval(function () {
            myChart.setOption({
                legend: {
                    selected: {
                        '出口': false,
                        '入口': false
                    }
                }
            })
            myChart.setOption({
                legend: {
                    selected: {
                        '出口': true,
                        '入口': true
                    }
                }
            })
        }, 10000)
    }
    _echarts_line_tow() {
        let container = this.refs.broken_line_two;
        let myChart = echarts.init(container);
        let arix_x = [1, 2, 3, 4, 5, 6], arix_y = [152, 289, 283, 296, 324, 256];
        let option = {
            backgroundColor: '#394056',
            title: {
                text: '湿度',
                textStyle: {
                    fontWeight: 'normal',
                    fontSize: 12,
                    color: '#F1F1F3'
                },
                left: '6%',
                top: '3%'
            },
            tooltip: {
                trigger: 'axis', //触发类型。[ default: 'item' ] :数据项图形触发，主要在散点图，饼图等无类目轴的图表中使用;'axis'坐标轴触发，主要在柱状图，折线图等会使用类目轴的图表中使用
                axisPointer: {
                    lineStyle: {
                        color: '#57617B'
                    }
                }
            },
            legend: {
                icon: 'rect', //设置图例的图形形状，circle为圆，rect为矩形
                itemWidth: 14, //图例标记的图形宽度[ default: 25 ] 
                itemHeight: 5, //图例标记的图形高度。[ default: 14 ] 
                itemGap: 13, //图例每项之间的间隔。横向布局时为水平间隔，纵向布局时为纵向间隔。[ default: 10 ] 
                data: ['移动', '电信', '联通'],
                right: '4%', //图例组件离容器右侧的距离
                textStyle: {
                    fontSize: 12,
                    color: '#F1F1F3'
                }
            },
            grid: {
                left: '3%', //grid 组件离容器左侧的距离。
                right: '4%', //grid 组件离容器右侧的距离。
                bottom: '3%', //grid 组件离容器下侧的距离。
                containLabel: true //grid 区域是否包含坐标轴的刻度标签[ default: false ] 
            },
            xAxis: [{
                type: 'category',
                boundaryGap: false, //坐标轴两边留白策略，类目轴和非类目轴的设置和表现不一样
                axisLine: {
                    lineStyle: {
                        color: '#F1F1F3' //坐标轴线线的颜色。
                    }
                },
                data: arix_x
            }],
            yAxis: [{
                type: 'value', //坐标轴类型。'value' 数值轴，适用于连续数据;'category' 类目轴，适用于离散的类目数据，为该类型时必须通过 data 设置类目数据;'time' 时间轴;'log' 对数轴.
                name: '（刻度）', //坐标轴名称。
                axisTick: {
                    show: false //是否显示坐标轴刻度
                },
                axisLine: {
                    lineStyle: {
                        color: '#F1F1F3' //坐标轴线线的颜色
                    }
                },
                axisLabel: {
                    margin: 10, //刻度标签与轴线之间的距离
                    textStyle: {
                        fontSize: 12 //文字的字体大小
                    }
                },
                splitLine: {
                    lineStyle: {
                        color: '#57617B' //分隔线颜色设置
                    }
                }
            }],
            series: [{
                name: '日调用数量',
                type: 'line',
                smooth: true,
                symbol: 'circle',
                symbolSize: 5,
                showSymbol: false,
                lineStyle: {
                    normal: {
                        width: 1
                    }
                },
                areaStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: 'rgba(0, 136, 212, 0.3)'
                        }, {
                            offset: 0.8,
                            color: 'rgba(0, 136, 212, 0)'
                        }], false),
                        shadowColor: 'rgba(0, 0, 0, 0.1)',
                        shadowBlur: 10
                    }
                },
                itemStyle: {
                    normal: {
                        color: 'rgb(0,136,212)',
                        borderColor: 'rgba(0,136,212,0.2)',
                        borderWidth: 12

                    }
                },
                data: arix_y
            },]
        };
        myChart.setOption(option);
    }
    _handle_close = () => {
        if (this.props.onClose) {
            this.props.onClose();
        }
    }
    render() {
        const { data } = this.props;
        return (
            <div className="tip-app-room_msg">
                <div className="tip-app-room_name">{data ? data.DISPLAY_NAME : "暂无"}</div>
                <ul className="tip-app-room_table">
                    <li>
                        <span>租户</span>
                        <span>人数</span>
                        <span>起租期</span>
                        <span>到期</span>
                    </li>
                    <li>
                        <span>景天城</span>
                        <span>200</span>
                        <span>2017.10</span>
                        <span>2020.10</span>
                    </li>
                    <li>
                        <span>能源费(￥)</span>
                        <span>物业费(￥)</span>
                        <span>停车费(￥)</span>
                        <span>维修费(￥)</span>
                    </li>
                    <li>
                        <span>1000</span>
                        <span>1000</span>
                        <span>1000</span>
                        <span>1000</span>
                    </li>
                </ul>
                <div className="tip-app-broken_line" ref='broken_line'></div>
                <div className="tip-app-broken_line_two" ref='broken_line_two'></div>
            </div>
        )
    }
}

export class TipAppRoom extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    componentDidMount() {

    }
    render() {
        const { data } = this.props;
        return (
            <div className="tip-app_room">
                <div className="tip-app_room_title">{data ? data.DISPLAY_NAME : "暂无"}</div>
                <ul className="tip-app_room_all">
                    <li><span>编码</span><span>{data ? data.DISPLAY_CODE : "暂无"}</span></li>
                    <li><span>高度</span><span>{data ? data.HEIGHT : "暂无"}</span></li>
                    <li><span>房间面积</span><span>{data ? data.AREA : "暂无"}</span></li>
                    <li><span>周长</span><span>{data ? data.PERIMETER : "暂无"}</span></li>
                    <li><span>净周长(除门宽)</span><span>{data ? data.NET_PERIMETER : "暂无"}</span></li>
                    <li><span>门数量</span><span>{data ? data.DOOR_COUNT : "暂无"}</span></li>
                    <li><span>墙面积</span><span>{data ? data.WALL_AREA : "暂无"}</span></li>
                </ul>
            </div>
        )
    }
}