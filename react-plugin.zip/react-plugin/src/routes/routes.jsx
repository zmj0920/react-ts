import React, { Component } from 'react';
import { HashRouter as Router, Route, Switch } from 'react-router-dom';
// import history from './history';

import Home from './../views/home';
import App from './../views/app';
// import Heat from './../views/heatmap';
class MRoute extends Component {
    constructor(props){
      super(props);
      this.state = { isPhone:false }
    }
    componentWillMount(){
      window.addEventListener("resize",()=>{
        let isIPhone = new RegExp('\\bAndroid|webOS|iPhone|iPod|BlackBerry\\b', 'ig').test(window.navigator.userAgent);
        this.setState({isPhone:isIPhone});
      })
      let isIPhone = new RegExp('\\bAndroid|webOS|iPhone|iPod|BlackBerry\\b', 'ig').test(window.navigator.userAgent);
      this.setState({isPhone:isIPhone});
    }
    render() {
        const { isPhone } = this.state;
        return (
            <Router>
              <Switch>
                {
                  isPhone ? <Route path="/" component={App}/> :<Route exact path="/" component={Home}/>
                }
                {/*<Route path="/app" component={App}/>
                <Route path="/heat" component={Heat}/>
                <Route component={NoMatch}/>*/}
              </Switch>
            </Router>
        );
    }
}

export default MRoute;