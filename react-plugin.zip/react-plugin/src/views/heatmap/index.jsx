import React, { Component } from 'react';
import styles from './index.css';
import HEATMAP from 'heatmap.js';
export default class HeatMap_Com extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {
        console.log(HEATMAP);
        this.init_heat_map()
    }
    init_heat_map = () => {
        let container = this.refs.container;
        let heatmap = HEATMAP.create({container: container});
        heatmap.setData({
          max: 5,
          data: [{ x: 10, y: 15, value: 5}, { x: 100, y: 15, value: 5}]
        });
    }
    render() {
        return (
            <div className={styles.heat_map} ref='container'></div>
            )
    }
}