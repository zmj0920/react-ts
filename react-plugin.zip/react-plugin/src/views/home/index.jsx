import React, { Component } from 'react';
import './index.css';
import axios from 'axios';
import Hex_md5 from 'md5';
import QS from 'qs';

import ThreeModel from './../lib/three.model';
import Login_form from './../../components/form';
import Room_tip, { Tab_out_Com, Tab_inner_Com } from './../../components/tip';

import GetUrlParam from './../../tools/GetUrlParam.js';

const ipSite_login = 'http://mobile.cnspec.cn:5000',
    ipSite_model = 'http://www.cnspec.cn';


class HomeView extends Component {
    constructor(props) {
        super(props);
        this.state = {
            share_lock_state: false,
            stare_lock_html: '私密',
            share_isShow: false,
            share_url: '',
            isShow_login: true,
            select_data: [],
            project: '',
            project_name: '',
            isShow_project: true,
            floor_data: [],
            btn_play: false,
            btn_on: 0,
            room_msg: false,
            room_msg_name: '',
            floorRooms: [],
            floorRooms_index: 0,
            floorRooms_item: '',
            project_tab_out: true,
            project_tab_inner: false,
            transform: false,
            click_mesh: '',

        };
        this.project = GetUrlParam('project');
        this.project_name = GetUrlParam('project_name');
        this.ps_number = GetUrlParam('ps_number');
        this.ps_key = GetUrlParam('ps_key');
        //分享
        this.share = GetUrlParam('share');
    }


    componentDidMount() {

        this._init_project();
    }


    _fetchData = (type, url, params, callback) => {
        if (type === 'GET') {
            axios.get(url, {
                params: params
            })
                .then(function (response) {
                    if (response.status === 200) {
                        callback(response.data);
                    }
                })
                .catch(function (error) {
                    console.log(error);
                });
        } else {
            axios.post(url, QS.stringify(params))
                .then(function (response) {
                    if (response.status === 200) {
                        callback(response.data);
                    }
                })
                .catch(function (error) {
                    console.log(error);
                });
        }
    }

    //初始化项目
    _init_project() {
        if (this.share == 'yes') {
            let data = { 'project': this.project, 'ID': this.ps_number, '令牌': this.ps_key };
            this._getFloor(this.project, data);
            this.setState(preState => (
                {
                    isShow_login: false,
                    isShow_project: false,
                    project: this.project,
                    project_name: this.project_name
                }
            )
            )
        } else {
            let isLogin = sessionStorage.getItem('user_data');
            if (isLogin) {
                this.setState({ isShow_login: false })
                this._getProjects(JSON.parse(isLogin))
            } else {
                this.setState({ isShow_login: true })
            }
        }




    }

    //登录
    _login_submit = (mobile, password) => {
        if (!mobile) {
            alert('请输入用户名');
            return false
        }
        if (!password) {
            alert('请输入密码');
            return false
        }
        let obj = {
            mobile: mobile,
            password: Hex_md5(password)
        }
        let url = ipSite_login + '/api/user/login';
        this._fetchData('POST', url, obj, this._handle_submitData)
    }


    _handle_submitData = (result) => {
        if (result.success === 1) {
            this._getProjects(result.data)
            this.setState({ isShow_login: false })
            sessionStorage.setItem("user_data", JSON.stringify(result.data));
        } else if (result.success === 0) {
            alert(result.message)
        } else {
            console.log(result.message)
        }
    }

    //锁定分享
    _Share_lock = () => {
        if (this.state.share_lock_state) {
            this.setState(preState => (
                {
                    share_lock_state: !preState.share_lock_state,
                    share_isShow: false,
                    stare_lock_html: '私密'
                }
            )
            )
        } else {
            this.setState(preState => (
                {
                    share_lock_state: !preState.share_lock_state,
                    stare_lock_html: '公开'
                }
            )
            )
        }
    }

    //分享
    _Share_url = () => {
        const { share_lock_state, project, project_name } = this.state;
        let url, url_name = escape(project_name);
        if (share_lock_state) {
            if (this.share === 'yes') {
                url = window.location.href;
            } else {
                let user_data = JSON.parse(sessionStorage.getItem('user_data'));
                if (project) {
                    if (window.location.search.indexOf('?') >= 0) {
                        if (window.location.search.indexOf('&') >= 0) {
                            url = window.location.href +
                                '&project=' + project +
                                '&project_name=' + url_name +
                                '&ps_number=' + user_data.ID +
                                '&ps_key=' + user_data.令牌 +
                                '&share=yes';
                        } else {
                            if (window.location.search.split('?')[1].length > 0) {
                                url = window.location.href +
                                    '&project=' + project +
                                    '&project_name=' + url_name +
                                    '&ps_number=' + user_data.ID +
                                    '&ps_key=' + user_data.令牌 +
                                    '&share=yes';
                            } else {
                                url = window.location.href +
                                    'project=' + project +
                                    '&project_name=' + url_name +
                                    '&ps_number=' + user_data.ID +
                                    '&ps_key=' + user_data.令牌 +
                                    '&share=yes';
                            }
                        }
                    } else {
                        url = window.location.href +
                            '?project=' + project +
                            '&project_name=' + url_name +
                            '&ps_number=' + user_data.ID +
                            '&ps_key=' + user_data.令牌 +
                            '&share=yes';
                    }
                } else {
                    alert('请选择项目');
                    return false
                }
            }
            this.setState(preState => ({
                share_isShow: !preState.share_isShow,
                share_url: url
            }))
        }
    }
    //复制链接
    _Share_copy = () => {
        this.refs.share_url.select();
        document.execCommand("Copy");
    }
    //关闭复制链接弹框
    _Share_url_close = () => {
        this.setState({ share_isShow: false })
    }
    //获取用户项目
    _getProjects = (data) => {
        let that = this;
        let url = ipSite_model + '/Scan3D.asmx/GetProjectM2Info?ps_member=' +
            data.ID + '&ps_m2_user=' +
            data.邮箱 + '&ps_key=' + data.令牌;
        let handle_select = function (result) {
            if (result.success === 1) {
                that.setState({ select_data: result.data })
            } else {
                console.log(result.message)
            }
        }
        this._fetchData('GET', url, {}, handle_select)
    }

    //选择项目获取数据
    _onSelect = (e) => {
        const { select_data } = this.state;
        if (e.target.value) {
            let data = sessionStorage.getItem("user_data");
            this._getFloor(e.target.value, JSON.parse(data));
            for (let i = 0; i < select_data.length; i++) {
                if (select_data[i].CODE === e.target.value) {
                    let title = select_data[i].NAME_CN;
                    this.setState(
                        {
                            project: e.target.value,
                            floorRooms: [],
                            project_name: title,
                            room_msg: false,
                            btn_play: false,
                            btn_on: 0
                        }
                    );
                }
            }
        } else {
            this.setState(
                {
                    floor_data: [],
                    btn_play: false,
                    btn_on: 0
                }
            );
        }
        if (this.newModel) {
            this.newModel.initClear();
        }
    }
    //获取楼层信息
    _getFloor(project, data) {
        let that = this;
        //楼层api
        let url = 'http://api.navimi.com.cn/CNSPEC.asmx/GetProjectSpaceFloor?ps_member=' +
            data.ID + '&ps_project=' +
            project + '&ps_key=' + data.令牌;
        let handleFloor = function (result) {
            if (result.success === 1) {
                that._btn_click(result.data[0])
                that.setState({ floor_data: result.data })
            } else {
                console.log(result.message)
            }
        }
        this._fetchData('GET', url, {}, handleFloor)
    }


    _btn_click = (e) => {
        let container = this.refs.container;
        if (this.share == 'yes') {
            let project_params = { 'project': this.project, 'ID': this.ps_number, '令牌': this.ps_key, };
            if (e.target) {
                this.newModel = new ThreeModel("PC", container, project_params, e.target.innerHTML,
                    {
                        x: 0,
                        y: 0,
                        z: 0
                    }, this.handle_room_msg);
                this.newModel.initThree();
                this.getFloorRooms(project_params, e.target.innerHTML);
                this.setState(
                    {
                        btn_on: e.target.getAttribute('data_index'),
                        project_tab_out: true,
                        project_tab_inner: false,
                        transform: false
                    }
                )
            } else {
                this.newModel = new ThreeModel("PC", container, project_params, e.FLOOR,
                    {
                        x: 0,
                        y: 0,
                        z: 0
                    },
                    this.handle_room_msg);
                this.newModel.initThree();
                this.getFloorRooms(project_params, e.FLOOR);
                this.setState(
                    {
                        btn_on: 0,
                        project_tab_out: true,
                        project_tab_inner: false,
                        transform: false
                    }
                )
            }
        } else {
            let project_data,
                user_data = sessionStorage.getItem('user_data');
            if (user_data) {
                project_data = JSON.parse(user_data);
                project_data.project = this.state.project;
            }
            if (e.target) {
                this.newModel = new ThreeModel("PC", container, project_data, e.target.innerHTML,
                    {
                        x: 0,
                        y: 0,
                        z: 0
                    },
                    this.handle_room_msg);
                this.newModel.initThree();
                this.getFloorRooms(project_data, e.target.innerHTML);
                this.setState(
                    {
                        btn_on: e.target.getAttribute('data_index'),
                        project_tab_out: true,
                        project_tab_inner: false,
                        transform: false
                    }
                )
            } else {
                this.newModel = new ThreeModel("PC", container, project_data, e.FLOOR,
                    {
                        x: 0,
                        y: 0,
                        z: 0
                    },
                    this.handle_room_msg);
                this.newModel.initThree();
                this.getFloorRooms(project_data, e.FLOOR);
                this.setState(
                    {
                        btn_on: 0,
                        project_tab_out: true,
                        project_tab_inner: false,
                        transform: false
                    }
                )
            }
        }
    }

    handle_room_msg = (mesh) => {
        if (mesh && mesh.model3D) {
            this.setState(
                {
                    room_msg: true,
                    room_msg_name: mesh.model3D.DISPLAY_NAME,
                    project_tab_out: false,
                    project_tab_inner: true,
                    floorRooms_item: mesh.model3D,
                    floorRooms_index: mesh.data_index,
                    click_mesh: mesh
                }
            )
        }
    }
    //获取楼层房间信息 
    getFloorRooms = (project_data, floor) => {
        let that = this;
        //空间api
        let url = 'http://api.navimi.com.cn/CNSPEC.asmx/GetProjectSpaceMaps?ps_project=' +
            project_data.project + '&ps_member=' +
            project_data.ID + '&ps_floor=0&ps_key=' + project_data.令牌;
        let handleRooms = function (result) {
            if (result.success === 1) {
                for (let i = 0; i < result.data.LevelMaps.length; i++) {
                    let item = result.data.LevelMaps[i];
                    if (item.LEVEL === floor) {
                        that.setState({ floorRooms: item.ROOM });
                        return false
                    }
                }
            } else {
                console.log(result.message)
            }
        }
        this._fetchData('GET', url, {}, handleRooms)
    }

    btn_rooms_click = (e) => {
        const { floorRooms, click_mesh } = this.state;
        if (click_mesh) {
            click_mesh.material.color.setHex(click_mesh.material.current_color);
            click_mesh.material.transparent = true;
        }
        for (var i = 0; i < floorRooms.length; i++) {
            let item = floorRooms[i];
            if (item.BIM_ID == e.target.getAttribute('data_id')) {
                let mesh = this.newModel.selectMesh(item);
                if (mesh) {
                    mesh.material.current_color = mesh.material.color.getHex();
                    mesh.material.color.setHex(0xD1D3D3);
                    mesh.material.transparent = false;
                    this.setState(preState => (
                        {
                            room_msg: true,
                            room_msg_name: mesh.model3D.DISPLAY_NAME,
                            project_tab_out: false,
                            project_tab_inner: true,
                            floorRooms_item: mesh.model3D,
                            floorRooms_index: mesh.data_index,
                            click_mesh: mesh
                        }
                    )
                    )
                }
                return false
            }
        }
    }


    _btn_play = () => {
        const { floorRooms, btn_play } = this.state;
        if (floorRooms.length > 0) {
            this.setState(preState => ({ btn_play: !preState.btn_play }))
        }
    }


    _btn_back = () => {
        const { click_mesh } = this.state;
        if (click_mesh) {
            click_mesh.material.color.setHex(click_mesh.material.current_color);
            click_mesh.material.transparent = true;
        }
        this.setState(
            {
                project_tab_out: true,
                project_tab_inner: false,
                room_msg: false,
                room_msg_name: '',
                floorRooms_item: '',
                floorRooms_index: 0,
                click_mesh: ''
            }
        );
    }

    //上一个房间
    _btn_prev = () => {
        const { floorRooms, floorRooms_index, click_mesh } = this.state;
        if (click_mesh) {
            click_mesh.material.color.setHex(click_mesh.material.current_color);
            click_mesh.material.transparent = true;
        }
        if (floorRooms_index > 0) {
            let mesh = this.newModel.selectMesh(floorRooms[floorRooms_index - 1]);
            if (mesh) {
                mesh.material.current_color = mesh.material.color.getHex();
                mesh.material.color.setHex(0xD1D3D3);
                mesh.material.transparent = false;
                this.setState(
                    {
                        room_msg_name: mesh.model3D.DISPLAY_NAME,
                        floorRooms_item: mesh.model3D,
                        floorRooms_index: mesh.data_index,
                        click_mesh: mesh
                    }
                );
            }
        }
    }


    //下一个楼层
    _btn_next = () => {
        const { floorRooms, floorRooms_index, click_mesh } = this.state;
        if (click_mesh) {
            click_mesh.material.color.setHex(click_mesh.material.current_color);
            click_mesh.material.transparent = true;
        }
        if (floorRooms_index < floorRooms.length - 1) {
            let mesh = this.newModel.selectMesh(floorRooms[floorRooms_index + 1]);
            if (mesh) {
                mesh.material.current_color = mesh.material.color.getHex();
                mesh.material.color.setHex(0xD1D3D3);
                mesh.material.transparent = false;
                this.setState(
                    {
                        room_msg_name: mesh.model3D.DISPLAY_NAME,
                        floorRooms_item: mesh.model3D,
                        floorRooms_index: mesh.data_index,
                        click_mesh: mesh
                    }
                
                );
            }
        }
    }


    //2D 3D切换
    _transform = () => {
        const { transform } = this.state;
        if (this.newModel) {
            if (transform) {
                this.newModel.initThree()
            } else {
                this.newModel.initTwo()
            }
            this.setState(preState => ({ transform: !preState.transform }))
        }
    }


    //重启
    _ResetModel = () => {
        const { transform } = this.state;
        if (this.newModel) {
            if (!transform) {
                this.newModel.initThree()
            } else {
                this.newModel.initTwo()
            }
        }
    }


    //切换
    _ToggleModel = () => {
        if (this.newModel) {
            this.newModel.toggleModel();
        }
    }

    _room_tip_close = () => {
        this.setState({ room_msg: false })
    }

    render() {
        const {
            transform,
            share_lock_state,
            stare_lock_html,
            share_isShow,
            share_url,
            isShow_login,
            select_data,
            floor_data,
            isShow_project,
            project_name,
            btn_play,
            btn_on,
            room_msg,
            room_msg_name,
            floorRooms,
            floorRooms_item,
            floorRooms_index,
            project_tab_out,
            project_tab_inner
        } = this.state;
        return (
            <div className="home">
                <div className="home-header">
                    <div className="home-header_title">{project_name}</div>
                    <div className="home-head_action">
                        <div className={share_lock_state ? "home-head_close" : ''} onClick={this._Share_lock}>{stare_lock_html}</div>
                        <div className={share_lock_state ? "home-head_share" : ''} onClick={this._Share_url}>分享</div>
                    </div>
                </div>
                {
                    share_isShow && <div className="home-share_url">
                        <input type="text" name="share_url" value={share_url} ref='share_url' />
                        <button className="home-share_copy" onClick={this._Share_copy}>Copy</button>
                        <div className="home-share_close" onClick={this._Share_url_close}></div>
                    </div>
                }
                <div className="home-transform">
                    {
                        isShow_project && <select className="home-projects" name="projecs" onChange={this._onSelect}>
                            <option value='' key='xxx' >请选择项目</option>
                            {
                                select_data.length > 0 && select_data.map(item =>
                                    <option value={item.CODE}
                                        key={item.INCODE}>
                                        {item.NAME_CN}
                                    </option>
                                )
                            }
                        </select>
                    }
                    <div className="home-transform_action" onClick={this._transform}>{transform ? '3D View' : '2D View'}</div>
                    <div onClick={this._ResetModel}>Reset</div>
                    <div onClick={this._ToggleModel}>Toggle</div>
                </div>
                <div className="home-btns">
                    {
                        floor_data.length > 0 && floor_data.map((item, index) => btn_on == index ?
                            <button className="home-btn_click"
                                style={{ border: '2px solid #00b7ce' }}
                                data_index={index}
                                key={item.FLOOR}
                                onClick={this._btn_click}>
                                {item.FLOOR}
                            </button> :
                            <button className="home-btn_click"
                                data_index={index}
                                key={item.FLOOR}
                                onClick={this._btn_click}>
                                {item.FLOOR}
                            </button>
                        )
                    }
                </div>
                <div className={btn_play ? "home-project_rooms home-project_rooms_on" : "home-project_rooms"}>
                    {
                        project_tab_out && <Tab_out_Com name={project_name} data={floorRooms} onBtn={this.btn_rooms_click} />
                    }
                    {
                        project_tab_inner && <Tab_inner_Com
                            room_index={floorRooms_index}
                            room_floor={floorRooms}
                            room_item={floorRooms_item}
                            onBack={this._btn_back}
                            onPrev={this._btn_prev}
                            onNext={this._btn_next} />
                    }
                    <div className={btn_play ? "home-room_play home-room_play_on" : "home-room_play"} onClick={this._btn_play} data_state="0"></div>
                </div>
                {
                    room_msg && <Room_tip name={room_msg_name} onClose={this._room_tip_close} />
                }
                <div className="home-container" ref='container'></div>
                {
                    isShow_login && <Login_form onSubmit={this._login_submit} />
                }
            </div>
        )
    }
}

export default HomeView;
