import React, { Component } from 'react';
import './style.css';
import axios from 'axios';
import Hex_md5 from 'md5';
import QS from 'qs';
import { Picker, List, Carousel } from 'antd-mobile';

import LoginForm from './../../components/form';
import { TipComApp, TipAppRoom } from './../../components/tip';
import ThreeModel from './../lib/three.model';
import GetUrlParam from './../../tools/GetUrlParam.js';

const ipSite_login = 'http://mobile.cnspec.cn:5000',
    ipSite_model = 'http://www.cnspec.cn',
    isSite_map = 'http://api.navimi.com.cn/';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            title: "",
            isMenu: false,
            isMenu_style: false,
            isHide: false,
            transform: false,
            sValue: [],
            isShow_login: false,
            projects: [],
            project_id: '',
            click_mesh: '',
            isCarousel: false,
            data: [1, 2],
            project_data: '',
            floorRoom: '',
        }
        this.project = GetUrlParam('project');
        this.project_name = GetUrlParam('project_name');
        this.ps_number = GetUrlParam('ps_number');
        this.ps_key = GetUrlParam('ps_key');
        this.share = GetUrlParam('share');
    }
    componentDidMount() {
        this._init_project();
    }


    _fetchData = (type, url, params, callback) => {
        if (type === 'GET') {
            axios.get(url, {
                params: params
            })
                .then(function (response) {
                    if (response.status === 200) {
                        callback(response.data);
                    }
                })
                .catch(function (error) {
                    console.log(error);
                });
        } else {
            axios.post(url, QS.stringify(params))
                .then(function (response) {
                    if (response.status === 200) {
                        callback(response.data);
                    }
                })
                .catch(function (error) {
                    console.log(error);
                });
        }
    }



    _init_project() {
        if (this.share === 'yes') {
            let data = { 'project': this.project, 'ID': this.ps_number, '令牌': this.ps_key },
                project_data = [
                    {
                        CODE: this.project, NAME_CN: this.project_name, label:
                            this.project_name, value: this.project
                    }
                ]
                ;
            this._getFloor(this.project, data);
            this.setState({ title: this.project_name, projects: project_data })
        } else {
            let isLogin = sessionStorage.getItem('user_data');
            if (isLogin) {
                this.setState({ isShow_login: false })
                this._getProjects(JSON.parse(isLogin))
            } else {
                this.setState({ isShow_login: true })
            }
        }
    }
    //手机端左侧带单
    _onchangeMenu = () => {
        this.setState(preState => ({ isMenu: !preState.isMenu, isMenu_style: true }));
    }

    //隐藏楼板
    _ontoggleModel = () => {
        if (this.newModel) {
            this.newModel.toggleModel();
        }
        this.setState(preState => ({ isMenu: false, isHide: !preState.isHide }))
    }
    //重置视角
    _onResetModel = () => {
        const { transform, project_result } = this.state;
        if (this.newModel) {
            if (!transform) {
                this.newModel.initThree(project_result)
            } else {
                this.newModel.initTwo(project_result)
            }
        }
        this.setState({ isMenu: false, isHide: false })
    }
    //二位三维切换
    _onTransform = () => {
        const { transform, project_result } = this.state;
        if (this.newModel) {
            if (transform) {
                this.newModel.initThree(project_result)
            } else {
                this.newModel.initTwo(project_result)
            }
            this.setState(preState => ({ isMenu: false, transform: !preState.transform, isHide: false }))
        }
    }

    _onPickerChange = (val) => {
        let that = this;
        if (val && val.length === 1) {
            setTimeout(() => {
                let isLogin = sessionStorage.getItem('user_data');
                that._getFloor(val[0], JSON.parse(isLogin));
            }, 200)
        } else {
            this.setState({ sValue: val });
        }
    }

    _getFloorMap = (project, user_data) => {
        let that = this,
            container = this.refs.container;
        //空间api
        let url = 'http://api.navimi.com.cn/CNSPEC.asmx/GetProjectSpaceMaps?ps_project=' +
            project[0] + '&ps_member=' +
            user_data.ID + '&ps_floor=0&ps_key=' + user_data.令牌;
        let handleRooms = function (result) {
            if (result.success === 1) {
                that.newModel = new ThreeModel("app", container, user_data, project[1], {
                    x: 0,
                    y: 0,
                    z: 0
                }, that.handle_room_msg);
                that.newModel.initThree(result);
                that.setState({ project_result: result });
            } else {
                console.log(result.message)
            }
        }
        this._fetchData('GET', url, {}, handleRooms)
    }

    _onPickerOk = (val) => {
        this._initModel();
        this.setState(preState => {
            for (let i = 0; i < preState.projects.length; i++) {
                if (preState.projects[i].CODE === val[0]) {
                    return ({ title: preState.projects[i].NAME_CN, isMenu: false, isHide: false })
                }
            }
        });
    }


    _initModel = () => {
        let { sValue, project_result, project_id } = this.state, container = this.refs.container;
        if (this.share === "yes") {
            let project_params = { 'project': this.project, 'ID': this.ps_number, '令牌': this.ps_key, };
            if (project_id === sValue[0] && project_result) {
                this.newModel = new ThreeModel("app", container, project_params, sValue[1], {
                    x: 0,
                    y: 0,
                    z: 0
                }, this.handle_room_msg);
                this.newModel.initThree(project_result);
            } else {
                this._getFloorMap(sValue, project_params);
                this.setState({ project_id: sValue[0] })
            }
        } else {
            let project_data,
                user_data = sessionStorage.getItem('user_data');
            if (user_data) {
                project_data = JSON.parse(user_data);
                project_data.project = sValue[0];
            }
            if (project_id === sValue[0] && project_result) {
                this.newModel = new ThreeModel("app", container, project_data, sValue[1], {
                    x: 0,
                    y: 0,
                    z: 0
                }, this.handle_room_msg);
                this.newModel.initThree(project_result);
            } else {
                this._getFloorMap(sValue, project_data);
                this.setState({ project_id: sValue[0] })
            }
        }
    }

    handle_room_msg = (mesh) => {
        if (mesh && mesh.model3D) {
            this.setState({ click_mesh: mesh.model3D, isCarousel: true })
        }
    }

    _getProjects = (data) => {
        let that = this;
        let url = ipSite_model + '/Scan3D.asmx/GetProjectM2Info?ps_member=' + data.ID + '&ps_m2_user=' + data.邮箱 + '&ps_key=' + data.令牌;
        let handle_select = function (result) {
            if (result.success === 1) {
                let project_data = result.data.map((item, index) => {
                    if (index === 0) {
                        that._getFloor(item.CODE, data);
                    }
                    item.label = item.NAME_CN;
                    item.value = item.CODE;
                    return item;
                });
                that.setState({ projects: project_data })
            } else {
                console.log(result.message)
            }
        }
        this._fetchData('GET', url, {}, handle_select)
    }


    //获取楼层信息
    _getFloor(project, data) {
        let that = this;
        //楼层api
        let url = 'http://api.navimi.com.cn/CNSPEC.asmx/GetProjectSpaceFloor?ps_member=' + data.ID +
            '&ps_project=' + project +
            '&ps_key=' + data.令牌;
        let handleFloor = function (result) {
            if (result.success === 1) {
                let floor_data = result.data.map((item, i) => {
                    item.label = item.FLOOR;
                    item.value = item.FLOOR;
                    return item;
                })
                that.setState(preState => {
                    for (let i = 0; i < preState.projects.length; i++) {
                        if (preState.projects[i].CODE === project) {
                            preState.projects[i].children = floor_data;
                            return ({ projects: preState.projects, sValue: [project, floor_data[0].FLOOR] })
                        }
                    }
                })
            } else {
                console.log(result.message)
            }
        }
        this._fetchData('GET', url, {}, handleFloor)
    }

    //登录
    _login_submit = (mobile, password) => {
        if (!mobile) {
            alert('请输入用户名');
            return false
        }
        if (!password) {
            alert('请输入密码');
            return false
        }
        let obj = {
            mobile: mobile,
            password: Hex_md5(password)
        }
        let url = ipSite_login + '/api/user/login';
        this._fetchData('POST', url, obj, this._handle_submitData)
    }


    _handle_submitData = (result) => {
        if (result.success === 1) {
            this._getProjects(result.data)
            this.setState({ isShow_login: false })
            sessionStorage.setItem("user_data", JSON.stringify(result.data));
        } else if (result.success === 0) {
            alert(result.message)
        } else {
            console.log(result.message)
        }
    }


    _toggleCarousel = () => {
        this.setState(preState => ({ isCarousel: !preState.isCarousel }))
    }

    render() {
        const {
            title,
            isMenu,
            isMenu_style,
            isHide,
            transform,
            projects,
            sValue,
            isShow_login,
            click_mesh,
            isCarousel
        } = this.state;
        return (
            <div className="App">
                <div className="App-header">
                    <div className="App-menu" onClick={this._onchangeMenu}></div>
                    <div className="App-name">{title}</div>
                    <div className="App-logo"></div>
                </div>
                <div className={isMenu ? "App-drawer App-drawer_on" : isMenu_style ?
                    "App-drawer App-drawer_close" :
                    "App-drawer App-drawer_close_first"}>
                    <div className="App-drawer_item">
                        <Picker
                            cols={2}
                            data={projects}
                            title="项目-楼层"
                            cascade={true}
                            extra="请选择(可选)"
                            value={sValue}
                            onPickerChange={this._onPickerChange}
                            onOk={this._onPickerOk}>
                            <List.Item arrow="horizontal">选择项目</List.Item>
                        </Picker>
                    </div>
                    <div className={isHide ?
                        "App-drawer_item App-drawer_item_floor" :
                        "App-drawer_item"
                    }
                        onClick={this._ontoggleModel}>隐藏楼板</div>
                    <div className="App-drawer_item" onClick={this._onResetModel}>重置视角</div>
                    <div className="App-drawer_item" onClick={this._onTransform}>
                        {transform ? "三维显示" : "二维显示"}
                    </div>
                </div>
                <div className="App-container" ref="container"></div>
                {
                    isCarousel && <div className="App-tip_cover">
                        <div className="App-tip_box">
                            <div className="App-tip-close" onClick={this._toggleCarousel}></div>
                            <Carousel autoplay={false} infinite>
                                <div className="App-carousel_item"><TipAppRoom data={click_mesh} /></div>
                                <div className="App-carousel_item"><TipComApp data={click_mesh} /></div>
                            </Carousel>
                        </div>
                    </div>
                }
                {
                    isShow_login && <LoginForm onSubmit={this._login_submit} />
                }
            </div>
        );
    }
}

export default App;
