


export default function GetUrlParam(name) {
    let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    let hrefSeach = '';
    if (window.location.hash.indexOf('?') >= 0) {
        hrefSeach = window.location.hash.split('?')[1];
    } else {
        return null;
    }
    let rl = hrefSeach.match(reg);
    if (rl != null) return unescape(rl[2]);
    return null;
}