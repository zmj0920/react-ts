


export default function ComputExtreme(data) {
    if (data && data.length > 0) {
        var data_length = data.length;
        var min_x = data[0],
            max_x = data,
            min_y,
            max_y
    }
}