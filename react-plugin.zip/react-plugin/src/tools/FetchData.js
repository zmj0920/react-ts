import axios from 'axios';
import QS from 'qs';





export default function FetchData(url, params, callback) {
    if(type === 'GET'){
        axios.get(url, {
            params: params
        })
        .then(function(response) {
            if (response.status === 200) {
                callback(response.data);
            }
        })
        .catch(function(error) {
                console.log(error);
        });
    }else{
        axios.post(url, QS.stringify(params))
          .then(function (response) {
            if (response.status === 200) {
                callback(response.data);
            }
          })
          .catch(function (error) {
            console.log(error);
          });
    }
}