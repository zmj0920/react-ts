import getUrlParam from './GetUrlParam.js';



export default function getUserData() {
	let user = sessionStorage.getItem("user_Data");
	user = eval('(' + user + ')');

	let myData = {
		token: '',
		userName: '',
		name: '',
		userId: '',
		mediaUserid: '',
		mediaApikey: ''
	};

	if (!user) {
		let isIPhone = new RegExp('\\biPhone\\b', 'ig').test(window.navigator.userAgent),
			isOnapp = getUrlParam('onapp') == 'yes' ? true : false;
		if (isOnapp) {
			if (isIPhone) {
				myData = JSON.parse(localStorage.getItem("user_Data"));
				if (myData && myData.token) {
					sessionStorage.setItem("user_Data", JSON.stringify(myData));
				} else {
					alert('没有获取到用户信息')
					window.OCModel.getLogin();
				}
			} else {
				let androidData = eval('(' + window.android.getUserInfo() + ')');
				myData = androidData.result
				if (myData && myData.token) {
					sessionStorage.setItem("user_Data", JSON.stringify(myData));
				} else {
					let localData = JSON.parse(localStorage.getItem("user_Data"));
					myData = localData.result
					if (myData && myData.token) {
						sessionStorage.setItem("user_Data", JSON.stringify(myData));
					} else {
						alert('没有获取到用户信息')
						window.android.goLogin();
					}
				}
			}
		} else {
			myData = {
				token: '9fd33c8ebea71b0e268e960df603fe2e',
				userName: '',
				name: '',
				userId: 9,
				mediaUserid: '1B1C9FC4-4F70-45D7-A983400013197E58',
				mediaApikey: '708E27D9EB1143199F433F05BFFF80BE'
			};
		}
	} else {
		myData = user;
	}
	return myData;
}   