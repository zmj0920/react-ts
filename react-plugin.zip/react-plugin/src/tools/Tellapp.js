


export default function tellApp() {
	let isIPhone = new RegExp('\\biPhone\\b', 'ig').test(window.navigator.userAgent);
	if (isIPhone) {
		window.webkit.messageHandlers.jsTaskNum.postMessage("");
	} else {
		window.android.Torefresh();
	}
}