import getUrlParam from './GetUrlParam.js';




export default function BeOverdue(json,toast){
    let isIPhone = new RegExp('\\biPhone\\b', 'ig').test(window.navigator.userAgent),
	    isOnapp=getUrlParam('onapp')=='yes'?true:false;
	if(isOnapp){
		if(isIPhone){
			if(json.code==401){
				sessionStorage.setItem("user_Data",'');
				if(toast){
					toast.info(json.msg, 1);
				}
				setTimeout(()=>{
					window.OCModel.getLogin();
				},1000)
			}else{
				console.log(json.msg)
			}
		}else{
			if(json.code==401){
				sessionStorage.setItem("user_Data",'');
				if(toast){
					toast.info(json.msg, 1);
				}
				setTimeout(()=>{
					window.android.goLogin();
				},1000)
			}else{
				console.log(json.msg)
			}
		}
	}else{

	}
}