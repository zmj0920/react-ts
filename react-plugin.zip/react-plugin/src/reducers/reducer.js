// action types
const INIT_COMMNET = 'INIT_COMMNET'
const ADD_COMMENT = 'ADD_COMMENT'
const DELETE_COMMENT = 'DELETE_COMMENT'

// reducer
export default function (state, action) {
  if (!state) {
    state = { meetPeople:[] }
  }
  switch (action.type) {
    case INIT_COMMNET:
      // 初始人员
      return {
        meetPeople:action.comments
      }
    case ADD_COMMENT:
      // 新增or删除人员
      return {
        meetPeople:action.comments
      }
    case DELETE_COMMENT:
      // 删除人员
      return {
        meetPeople: [
          ...state.meetPeople.slice(0, action.commentIndex),
          ...state.meetPeople.slice(action.commentIndex + 1)
        ]
      }
    default:
      return state
  }
}

// action creators
export const initConent = (comments) => {
  return { type: INIT_COMMNET, comments }
}

export const addOrDelConent = (comments) => {
  return { type: ADD_COMMENT, comments}
}

export const deleteComment = (commentIndex) => {
  return { type: DELETE_COMMENT, commentIndex }
}
