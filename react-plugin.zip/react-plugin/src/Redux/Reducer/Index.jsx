import { GO_LOGIN,OUT_LOGIN } from './../Action/Index'

function myLogin(state, action){
    switch (action.type) {
        case GO_LOGIN:
            //登录
            return true
        case OUT_LOGIN:
            //退出登录
            return false
        default:
            return state
    }
}
export default myLogin