export const GO_LOGIN = 'GO_LOGIN'
export const OUT_LOGIN = 'OUT_LOGIN';